#include<TinyGPS.h>
float lat=12.91,lon=77.57;

TinyGPS gps;
void gps_read();

 void gps_read()
{
  unsigned long start=millis();
while(millis()-start<2001)
{
    while(Serial.available())
    if(gps.encode(Serial.read()))
    {
    gps.f_get_position(&lat,&lon);
    }
}  
     
}
